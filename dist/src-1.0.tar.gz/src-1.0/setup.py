from setuptools import setup,find_packages

setup(
    
    name="src",
    version="1.0",
    description="my own mlops package i have created"
    ,author="Rohan Patankar",package=list,
    packages=find_packages(),
    license="MIT"
)
